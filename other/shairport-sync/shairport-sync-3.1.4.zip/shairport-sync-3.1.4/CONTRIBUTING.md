
Contributing to Shairport Sync
====

If you would like to contribute to the development of Shairport Sync, please make you changes to the `development` branch and make a pull request.

Changes and additions in the development branch make their way eventually to the `master` branch.
