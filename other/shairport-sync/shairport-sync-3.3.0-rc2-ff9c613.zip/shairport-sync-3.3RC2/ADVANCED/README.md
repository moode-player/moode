Advanced Topics [Under Construction]
======

Shairport Sync has many advanced features.
Some may enhance the audio experience and some may be of interest if you want to integrate Shairport Sync into an existing system
Some advanced features allow you to get metadata about the material being played, including cover art, and some remote control of the audio source may be available.

Configuration Options
------
Please take a look at [CONFIGURATION_OPTIONS.md](CONFIGURATION_OPTIONS.md) for a discussion of the options you can use when configuring the building of Shairport Sync.
