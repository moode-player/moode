// cmMod.hpp (B)
#pragma once

#error "cmMod.hpp in incB must not be included"
