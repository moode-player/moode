// cmMod.hpp (M)
#pragma once

#error "cmMod.hpp in incM must not be included"
