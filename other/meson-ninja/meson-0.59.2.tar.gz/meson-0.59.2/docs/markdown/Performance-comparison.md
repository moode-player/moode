# Performance comparison

This page lists experiments comparing build performance between Meson
and other build systems.

- [Simple comparison](Simple-comparison.md)
- [ARM performance test](ARM-performance-test.md)
