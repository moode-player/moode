
template bool stringToStrings(
    const std::string&, std::vector<std::string>&, const std::string&);
template std::string stringsToString(const std::vector<std::string>&);
