
CLIENT_ID = '5b4e1f241a734668aaddf170017d9244'
CLIENT_SECRET = '9bd49518f7974f8ebb6f965ae641022b'
REDIRECT_URI = 'https://www.lesbonscomptes.com/spotify/'
SCOPE = "playlist-read-private playlist-read-collaborative user-library-read user-read-recently-played user-top-read user-follow-read"
