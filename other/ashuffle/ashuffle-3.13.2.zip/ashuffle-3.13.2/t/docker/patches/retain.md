This file exists to make sure that this directory is retained by git.
