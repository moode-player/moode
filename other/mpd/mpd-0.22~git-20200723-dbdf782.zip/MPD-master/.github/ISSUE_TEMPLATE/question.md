---
name: Question
about: Ask a question about MPD
---

<!-- Before you ask a question on GitHub, please read MPD's
documentation.  A copy is available at
https://www.musicpd.org/doc/html/ -->
## Question
