#error This must not compile
