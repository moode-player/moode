int get_st2_prop (void);
int get_st3_prop (void);

int get_st1_value (void) {
  return get_st2_prop () + get_st3_prop ();
}
