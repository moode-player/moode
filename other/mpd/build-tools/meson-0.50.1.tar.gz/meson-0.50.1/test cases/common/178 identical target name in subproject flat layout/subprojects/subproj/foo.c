int meson_test_subproj_foo(void) { return 20; }
