#define VAL 42
