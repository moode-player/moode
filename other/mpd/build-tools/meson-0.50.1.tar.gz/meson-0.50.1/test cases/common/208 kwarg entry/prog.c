#include<prog.h>
#include<stdio.h>

int main(int argc, char **argv) {
    printf(MESSAGE);
    return 0;
}
