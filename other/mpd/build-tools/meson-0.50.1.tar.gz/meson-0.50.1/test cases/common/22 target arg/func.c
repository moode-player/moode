#ifndef CTHING
#error "Local argument not set"
#endif

#ifdef CPPTHING
#error "Wrong local argument set"
#endif

int func() { return 0; }
