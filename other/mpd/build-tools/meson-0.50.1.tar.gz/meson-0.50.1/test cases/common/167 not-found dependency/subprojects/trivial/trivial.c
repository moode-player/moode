int subfunc() {
    return 42;
}
