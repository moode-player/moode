#pragma once

int hidden_function();
