#include"bob.h"

int hidden_function() {
    return 7;
}
