#include<stdio.h>

int main(int argc, char **argv) {
    printf("This is test #2.\n");
    return 0;
}
