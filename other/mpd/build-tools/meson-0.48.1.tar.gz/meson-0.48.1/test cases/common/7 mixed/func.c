int func() {
    int class = 0;
    return class;
}
