#include"source1.h"
#include"source2.h"

int main(int argc, char **argv) {
    return func1() + func2();
}
