int func4() {
    return 4;
}
