int func();

int main(int argc, char **arg) {
    return func();
}
