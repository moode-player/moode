int libfun();

int main() {
  return libfun();
}
