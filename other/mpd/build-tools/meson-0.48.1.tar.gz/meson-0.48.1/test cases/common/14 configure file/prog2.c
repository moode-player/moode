#include<config2.h>

int main(int argc, char **argv) {
    return ZERO_RESULT;
}
