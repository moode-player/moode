/* This file goes to subdirectory of include root. */

int subdir_func();
