#!/usr/bin/env python3

print('1.2')
