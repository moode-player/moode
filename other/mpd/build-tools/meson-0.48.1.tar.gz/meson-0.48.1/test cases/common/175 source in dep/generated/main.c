#include"funheader.h"

int main(int argc, char **argv) {
    return my_wonderful_function() != 42;
}
