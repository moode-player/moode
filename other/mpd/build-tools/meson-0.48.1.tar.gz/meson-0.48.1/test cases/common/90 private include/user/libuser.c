#include"foo1.h"
#include"foo2.h"

int main(int argc, char **argv) {
    return foo1() + foo2();
}
