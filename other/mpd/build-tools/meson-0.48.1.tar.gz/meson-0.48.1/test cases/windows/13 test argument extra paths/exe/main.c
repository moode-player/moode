#include <foo.h>

int main(int ac, char **av) {
  return foo_process();
}
