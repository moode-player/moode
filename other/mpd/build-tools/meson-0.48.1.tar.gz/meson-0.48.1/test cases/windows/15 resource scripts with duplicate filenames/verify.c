#include <assert.h>
#include <windows.h>

int main(int arc, char *argv[])
{
  // verify that the expected resource exists and has the expected contents
  HRSRC hRsrc;
  unsigned int size;
  HGLOBAL hGlobal;
  void* data;

  hRsrc = FindResource(NULL, argv[1], RT_RCDATA);
  assert(hRsrc);

  size = SizeofResource(NULL, hRsrc);
  hGlobal = LoadResource(NULL, hRsrc);
  data = LockResource(hGlobal);

  assert(size == strlen(argv[1]));
  assert(memcmp(data, argv[1], size) == 0);

  return 0;
}
