---
name: Bug report
about: Create a bug report
---

<!-- See https://www.musicpd.org/help/ -->
## Bug report
### Describe the bug


## Expected Behavior


## Actual Behavior


## Version
<!-- Paste the output of "mpd --version" here -->


## Log
<!-- Paste relevant portions of the log file here (--verbose) -->
