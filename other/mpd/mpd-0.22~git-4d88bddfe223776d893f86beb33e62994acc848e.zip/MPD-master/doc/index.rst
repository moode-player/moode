Music Player Daemon
===================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   user
   plugins
   developer
   protocol


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
