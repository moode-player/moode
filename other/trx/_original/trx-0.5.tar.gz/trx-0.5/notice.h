#ifndef NOTICE_H
#define NOTICE_H

#define COPYRIGHT "trx (C) Copyright 2020 Mark Hills <mark@xwax.org>"

#endif
