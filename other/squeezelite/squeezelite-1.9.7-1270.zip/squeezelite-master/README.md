Squeezelite v1.9.x, Copyright 2012-2015 Adrian Smith, 2015-2019 Ralph Irving.<br>
<br>
See the squeezelite manpage for usage details.<br>
https://ralph-irving.github.io/squeezelite.html<br>
<br>
This program is free software: you can redistribute it and/or modify<br>
it under the terms of the GNU General Public License as published by<br>
the Free Software Foundation, either version 3 of the License, or<br>
(at your option) any later version.<br>
<br>
This program is distributed in the hope that it will be useful,<br>
but WITHOUT ANY WARRANTY; without even the implied warranty of<br>
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br>
GNU General Public License for more details.<br>
<br>
You should have received a copy of the GNU General Public License<br>
along with this program.  If not, see <http://www.gnu.org/licenses/>.<br>
<br>
Contains dsd2pcm library Copyright 2009, 2011 Sebastian Gesemann which<br>
is subject to its own license.<br>
<br>
Contains the Daphile Project full dsd patch Copyright 2013-2017 Daphile,<br>
which is subject to its own license.<br>
<br>
Option to allow server side upsampling for PCM streams (-W) from<br>
squeezelite-R2 (c) Marco Curti 2015, marcoc1712@gmail.com.<br>
<br>
RaspberryPi minimal GPIO Interface<br>
http://abyz.me.uk/rpi/pigpio/examples.html#Misc_minimal_gpio.<br>
<br>
This software uses libraries from the FFmpeg project under<br>
the LGPLv2.1 and its source can be downloaded from<br>
https://sourceforge.net/projects/lmsclients/files/source/<br>
